﻿namespace Documents.Cache
{
    public enum CacheAccessType
    {
        Hit,
        Miss,
    }
}
